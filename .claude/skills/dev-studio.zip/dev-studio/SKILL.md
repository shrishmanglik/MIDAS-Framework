---
name: dev-studio
description: "Full-stack development studio. Builds production-grade applications from architecture specs through deployment. The engineering powerhouse of MIDAS."
activation: "build, code, implement, API, frontend, backend, database, deploy, test, scaffold"
tier: 2
dependencies: [design-studio, research-studio]
---

# Dev Studio — VP of Engineering

## Mission
Build production-grade, secure, tested applications from architecture specs.

## Team Roster
| Agent | File | Spawning | Primary Output |
|-------|------|----------|----------------|
| Product Manager | agents/product-manager.md | Inline | Structured requirements |
| Systems Architect | agents/systems-architect.md | Inline/Subagent | Architecture specs |
| Backend Developer | agents/backend-developer.md | Subagent | FastAPI code |
| Frontend Developer | agents/frontend-developer.md | Subagent | React/Next.js code |
| Database Engineer | agents/database-engineer.md | Subagent | Models, migrations |
| QA Engineer | agents/qa-engineer.md | ALWAYS Subagent | Test suites, review |
| DevOps Engineer | agents/devops-engineer.md | Subagent | Docker, CI/CD |
| Technical Writer | agents/technical-writer.md | Inline | API docs, READMEs |
| Performance Engineer | agents/performance-engineer.md | Subagent | Optimization reports |

## Pipeline
```
Brief → [PM: Requirements] → [Architect: Design] → [DB: Schema] → [Backend: API]
  → [Frontend: UI] → [QA: Test+Review] → [DevOps: Deploy] → Production
```

## Spawning Rules
- **ALWAYS subagent:** qa-engineer (adversarial — code review must be independently verified)
- **ALWAYS inline:** product-manager (requirements are short structured output)
- **Context-dependent:** systems-architect (inline for small changes, subagent for full architecture); backend-developer, frontend-developer, database-engineer (subagent for implementation); devops-engineer (subagent for Docker/CI/CD); technical-writer (inline for READMEs)

## Budget
| Phase | Estimated Cost | Model |
|-------|---------------|-------|
| Requirements | $0.005 | haiku/sonnet |
| Architecture | $0.020 | sonnet/opus |
| Database | $0.015 | sonnet |
| Backend | $0.040 | sonnet |
| Frontend | $0.040 | sonnet |
| Testing | $0.020 | sonnet |
| Deployment | $0.005 | haiku |
| **Total** | **$0.145** | — |

## Quality Gates
- **Schema Compliance:** All output matches defined schemas
- **Test Coverage:** Minimum 80% for backend, 70% for frontend
- **Security:** No OWASP Top 10 vulnerabilities, parameterized queries, proper auth
- **Performance:** API response < 200ms p95, bundle < 250KB gzipped
- **Accessibility:** WCAG 2.1 AA compliance for all UI

## Integration Points
- Receives FROM design-studio: design tokens, component specs, interaction patterns
- Receives FROM research-studio: technology evaluation, architecture recommendations
- Provides TO devops-studio: deployment artifacts
- When loaded WITH design-studio: design specs become implementation requirements

## Templates Available
| Template | File | When to Use | Tier |
|----------|------|-------------|------|
| Requirements Doc | templates/requirements-doc.md | New project requirements | 1 |
| Architecture Spec | templates/architecture-spec.md | System design | 2 |
| API Endpoint | templates/api-endpoint.md | New API route | 1 |
| React Component | templates/react-component.md | New UI component | 1 |
| DB Model | templates/db-model.md | New data model | 1 |
| Test Suite | templates/test-suite.md | Test creation | 1 |
| Docker Config | templates/docker-config.md | Containerization | 1 |
| CI/CD Pipeline | templates/cicd-pipeline.md | Pipeline setup | 1 |
| Migration Script | templates/migration-script.md | DB migration | 1 |
| API Documentation | templates/api-docs.md | API docs | 1 |
| README | templates/readme.md | Project README | 1 |
