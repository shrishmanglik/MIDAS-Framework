---
name: design-studio
description: "Design studio for UI/UX. Creates beautiful, usable, accessible interfaces and visual systems. Produces specifications that dev-studio implements."
activation: "design, wireframe, UI/UX, accessibility, design system, mockup, prototype"
tier: 2
dependencies: [brand-studio]
---

# Design Studio — VP of Design

## Mission
Create beautiful, usable, accessible interfaces and visual systems.

## Team Roster
| Agent | File | Spawning | Primary Output |
|-------|------|----------|----------------|
| Design Director | agents/design-director.md | Inline | Creative direction |
| UX Researcher | agents/ux-researcher.md | Inline/Subagent | Usability analysis |
| UI Designer | agents/ui-designer.md | Subagent | Component designs |
| Interaction Designer | agents/interaction-designer.md | Inline | Animation specs |
| Design System Architect | agents/design-system-architect.md | Subagent | Design tokens, component library |
| Accessibility Auditor | agents/accessibility-auditor.md | ALWAYS Subagent | WCAG audit reports |
| Responsive Specialist | agents/responsive-specialist.md | Inline | Breakpoint strategy |

## Pipeline
```
Brief → [Director: Strategy] → [UX: Research] → [UI: Design] → [Interaction: Animate]
  → [Design System: Systematize] → [A11y Auditor: Review] → Handoff to dev
```

## Spawning Rules
- **ALWAYS subagent:** accessibility-auditor (adversarial — WCAG compliance must be independently verified)
- **ALWAYS inline:** design-director, interaction-designer, responsive-specialist (short deterministic output)
- **Context-dependent:** ux-researcher (inline for heuristics, subagent for full audits); ui-designer, design-system-architect (subagent for large output)

## Budget
| Phase | Estimated Cost | Model |
|-------|---------------|-------|
| Strategy | $0.005 | haiku |
| Research | $0.015 | sonnet |
| Design | $0.040 | sonnet |
| Systematize | $0.020 | sonnet |
| Review | $0.010 | sonnet |
| **Total** | **$0.090** | — |

## Quality Gates
- **WCAG Compliance:** All UI output meets WCAG 2.1 AA
- **Visual Consistency:** Design tokens applied consistently
- **Responsiveness:** All layouts tested at mobile/tablet/desktop breakpoints

## Integration Points
- Provides TO dev-studio: design tokens, component specs, interaction patterns
- Receives FROM brand-studio: brand guidelines, color palette, typography
- When loaded WITH dev-studio: design specs become implementation requirements

## Templates Available
| Template | File | When to Use | Tier |
|----------|------|-------------|------|
| Design Tokens | templates/design-tokens.md | New design system | 1 |
| Component Spec | templates/component-spec.md | Component design | 2 |
| Page Layout | templates/page-layout.md | Page design | 1 |
| Interaction Spec | templates/interaction-spec.md | Animation design | 2 |
| Breakpoints | templates/responsive-breakpoints.md | Responsive design | 1 |
| A11y Checklist | templates/a11y-checklist.md | Accessibility review | 1 |
